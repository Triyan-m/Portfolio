import csv
#Back end

#creates the list that stores all the accounts once imported from the csv
directory = []

#creates the building blocks for the object account
class Account:
    #the constructor is what is used to create the object. it takes in parameters of the account holder, account number and balance
    def __init__(self, name, accountnum: int, balance: float):
        self.name = name
        self.accountnum = accountnum
        self.balance = balance

    #Gets the account number from the chosen object and returns
    def getAccountnum(self) -> int:
        return self.accountnum

    #Method to add money to the account
    def addMoney(self, ammount):
        a = float(ammount)
        b = float(self.balance)
        self.balance = b + a

    #Method to remove money from the account. It checks for sufficient funds before deducting
    def removeMoney(self, ammount: float):
        a = float(ammount)
        b = float(self.balance)
        if a <= b:
            self.balance = b - a
        else:
            print("Error. Insufficient funds")

    #Transfers money between accounts. Takes in the ammoun and the reciever account
    def transfer(self, ammount, reciever):
        self.removeMoney(ammount)
        reciever.addMoney(ammount)

    #Prints the accounts details in a detailed form
    def view(self):
        print("Account holder: " + self.name)
        print("Account number: " + str(self.accountnum))
        print("Balance: " + str(self.balance) + "\n")

#Opens the csv file and iterates through the list creating an account with each row of the csv
with open('BankData.csv', 'r') as f:
    reader = csv.reader(f)
    for row in reader:
        directory.append(Account(row[0], row[1], row[2]))
        
#method for saving by opening the csv and iterating through the list and saving all the account data
def save():
    
    with open('BankData.csv', 'w', newline='') as f:
        field_names = ['Account Holder', 'Account Number', 'Balance']
        writer = csv.DictWriter(f, fieldnames=field_names)

        for account in directory:
            writer.writerow({'Account Holder': account.name, 'Account Number': account.accountnum, 'Balance': account.balance})

#method for viewing all the accounts in the list by iterating through the array counting all the accounts and then going through the array again from the 1st spot to the last viewing each account using the view()            
def printDirec():
    size = 0
    for i in directory:
        size = size + 1

    for i in range(1, size):
        directory[i].view()

#method for adding an account by getting the name and account number from the user and then adding balance if the user wants. Then creating a new account with the details
def addAccount():
    name = input("Enter name: ")
    accountnum = input("Enter account number: ")
    balance = 0

    proceed = False

    while proceed == False:
        add = input("\nWould you like to add balance to this account? (y/n)")
        if add == "y" or add == "n":
            proceed = True
        else:
            print("Error invalid answer. Try again")

    check = False
    
    if add == "y":
        while check == False:
            try:
                balance = int(input("\nAmount: "))
            except ValueError:
                print("\nInvalid input. Type an integer and try again")

            if balance > 0:
                check = True
            elif balance < 0:
                print("Insufficient value. Cant go under 0")
    

    directory.append(Account(name, accountnum, balance))

    save()

#Method to get the index by iterating it through the list and checking if each account has the account number that matches
def getIndex(accountnum):
    size = 0
    for i in directory:
        size = size + 1

    for i in range(1, size):
        if directory[i].getAccountnum() == str(accountnum):
            return i

#the method to transfer money between accounts by getting the giver, reciever accounts and the amount to transfer from the user then runs transfer()
def transferseq():
    print("Which account would you like to transfer from?")
    transferfrom = input("Enter account number: ")

    f = getIndex(transferfrom)

    while f == None:
        print("Error invalid account number")
        f = getIndex(input("Enter account number: "))
        

    print("\nWhich account would you like to transfer to?")
    transferto = input("Enter account number: ")

    t = getIndex(transferto)
    while t == None:
        print("Error invalid account number")
        t = getIndex(input("Enter account number: "))

    print("\nHow much would you like to transfer?")
    ammount = input("Enter amount: ")

    directory[f].transfer(ammount, directory[t])

    save()

    directory[f].view()
    directory[t].view()

#The method to withdraw from an account by getting the account and amount from the user and running removeMoney()
def withdrawseq():
    print("Which account would you like to withdraw from?")
    w = getIndex(input("Enter account number: "))

    while w == None:
        print("Error invalid account number")
        w = getIndex(input("Enter account number: "))

    print("\nHow much would you like to remove?")
    ammount = input("Enter amount: ")
    
    directory[w].removeMoney(ammount)
    save()
    directory[w].view()

#The method to add money to someones account by getting the account number and amount from the user then runnin addMoney()
def depositseq():
    print("Which account would you like to deposit to?")
    d = getIndex(input("Enter account number: "))

    while d == None:
        print("Error invalid account number")
        d = getIndex(input("Enter account number: "))

    print("\nHow much would you like to add?")
    ammount = input("Enter amount: ")

    directory[d].addMoney(ammount)
    save()
    directory[d].view()
                    

#Front end
print("********************************")
print("*   The CypressCrest Finance   *")
print("********************************\n")
print("Welcome back")

#Login
In = False
while In == False:
    password = input("\nPassword: ")
    if password == "admin":
        In = True
    else:
        print("Invalid password. Try again")

    
#the menu system that takes the users option and runs the complimentary method
while True:
    option = False
    print("\nWhat would you like to do today? \n1.View accounts \n2.Deposit to account \n3.Withdraw from account \n4.Transfer between accounts \n5.Create an account")
    while option == False:
        choice = input("\nEnter number: ")
        if choice == "1" or choice == "2" or choice == "3" or choice == "4" or choice == "5":
            option = True
        else:
            print("\nError invalid input")

    if choice == "1":
        printDirec()
    elif choice == "2":
        depositseq()
    elif choice == "3":
        withdrawseq()
    elif choice == "4":
        transferseq()
    elif choice == "5":
        addAccount()

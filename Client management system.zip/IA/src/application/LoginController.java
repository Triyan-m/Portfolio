package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


import admin.AdminController;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class LoginController implements Initializable{
	LoginModel loginModel = new LoginModel();
	
	//gets the text fields and buttons
	
	@FXML
	private Label dbstatus;
	@FXML
	private TextField username;
	@FXML
	private PasswordField password;
	@FXML
	private Button loginButton;
	@FXML
	private Label loginStatus;
	
	
	// If the database is connected it changes the label to say it is connected
	public void initialize(URL url, ResourceBundle rb) {
		if(this.loginModel.isDatabaseConnected()) {
			this.dbstatus.setText("Connected to Database");
		}else {
			this.dbstatus.setText("Not Connected to Database");
		}
		
	}

	// runs the login method when the button is pressed
	public void Login(ActionEvent event) throws IOException {
		checkLogin();
	}
	
	//checks if the username and password entered are correct
	private void checkLogin() throws IOException {
		LoginApp m = new LoginApp();
		// If it is correct it runs the userLogin method
		if(this.username.getText().equals("user") && this.password.getText().equals("admin")) {
			Stage stage = (Stage)this.loginButton.getScene().getWindow();
			stage.close();
			userLogin();
		}
		else {
			// if they are not connected it changes a label to say wrong
			this.loginStatus.setText("Wrong Credentials");
		}
	}
	//opens the 
	public void userLogin() {
		try {
			Stage userStage = new Stage();
			FXMLLoader userLoader = new FXMLLoader();
			Pane userroot = (Pane)userLoader.load(getClass().getResource("/admin/adminFXML.FXML").openStream());
			
			AdminController adminController = (AdminController)userLoader.getController();
			
			Scene scene = new Scene(userroot);
			userStage.setScene(scene);
			userStage.setTitle("Dashboard");
			userStage.setResizable(false);
			userStage.show();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

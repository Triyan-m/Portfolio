package application;

import java.sql.Connection;
import java.sql.SQLException;

import dbUtil.dbConnection;

public class LoginModel {

	// gets the database connection
	Connection connection;
	
	public LoginModel() {
		try {
			this.connection = dbConnection.getConnection();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		if(this.connection == null) {
			System.exit(1);
		}
	}
	
	public boolean isDatabaseConnected() {
		return this.connection !=null;
	}
	

	
	
}

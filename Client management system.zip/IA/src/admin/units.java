package admin;

public enum units {

	KG , Tons;
	
	private units () {}
	
	public String value() {
		return name();
	}
	
	public static units fromValues(String v) {
		return valueOf(v);
	}
}

package admin;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class clientData {

	private final StringProperty clientname;
	private final StringProperty salescontract;
	private final StringProperty supplier;
	private final StringProperty destination;
	
	public clientData(String clientName, String salesContract, String Supplier, String Destination) {
		
		this.clientname = new SimpleStringProperty(clientName);
		this.salescontract = new SimpleStringProperty(salesContract);
		this.supplier = new SimpleStringProperty(Supplier);
		this.destination = new SimpleStringProperty(Destination);
	}

	//Setters
	public void setClientname(String clientname) {
		this.clientname.set(clientname);
	}
	
	public void setSalescontract(String salescontract) {
		this.salescontract.set(salescontract);
	}
	
	public void setSupplier(String supplier) {
		this.supplier.set(supplier);
	}
	
	public void setDestination(String destination) {
		this.destination.set(destination);
	}
	
	
	//Getters
	public String getClientname() {
		return clientname.get();
	}
	
	public String getSalescontract() {
		return salescontract.get();
	}
	
	public String getSupplier() {
		return supplier.get();
	}
	
	public String getDestination() {
		return destination.get();
	}
	
	
	//String properties
	public StringProperty ClientnameProperty() {
		return clientname;
	}

	public StringProperty SalescontractProperty() {
		return salescontract;
	}

	public StringProperty SupplierProperty() {
		return supplier;
	}

	public StringProperty DestinationProperty() {
		return destination;
	}
	
	
	
	
}

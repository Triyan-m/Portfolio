package admin;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import dbUtil.dbConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class AdminController implements Initializable {
	
	//Client menu
	
	//calls in the text fields and columns for the client page
	@FXML
	private TextField clientname;
	@FXML
	private TextField salescontract;
	@FXML
	private TextField supplier;
	@FXML
	private TextField destination;
	@FXML
	private TextField searchclient;
	
	@FXML
	private TableView<clientData> clientTable;
	
	@FXML
	private TableColumn<clientData, String> clientnamecolumn;
	@FXML
	private TableColumn<clientData, String> salescontractcolumn;
	@FXML
	private TableColumn<clientData, String> suppliercolumn;
	@FXML
	private TableColumn<clientData, String> destinationcolumn;
	
	private dbConnection dc;
	private ObservableList<clientData> data;
	
	private String sql = "SELECT * FROM clients";
	
	public void initialize(URL url, ResourceBundle rb) {
		this.dc = new dbConnection();
		this.unit.setItems(FXCollections.observableArrayList(units.values()));
	}
	
	@FXML
	private void loadclientData(ActionEvent event) throws SQLException {
		
		try {
			
			Connection conn = dbConnection.getConnection();
			this.data = FXCollections.observableArrayList();
			
			ResultSet rs = conn.createStatement().executeQuery(sql);
			while (rs.next()) {
				this.data.add(new clientData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
			}
			
			
		} catch (SQLException e) {
			System.err.println("Error" + e);
		}
		
		
		this.clientnamecolumn.setCellValueFactory(new PropertyValueFactory<clientData, String>("clientname"));
		this.salescontractcolumn.setCellValueFactory(new PropertyValueFactory<clientData, String>("salescontract"));
		this.suppliercolumn.setCellValueFactory(new PropertyValueFactory<clientData, String>("supplier"));
		this.destinationcolumn.setCellValueFactory(new PropertyValueFactory<clientData, String>("destination"));
		
		this.clientTable.setItems(null);
		this.clientTable.setItems(this.data);
		
	}
	
	@FXML
	private void addClient(ActionEvent event) {
		String sqlInsert = "insert into clients(cname, scnum, supplier, destination) values (?, ?, ?, ?)";
		
		try {
			
			Connection conn = dbConnection.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sqlInsert);
			
			stmt.setString(1, this.clientname.getText());
			stmt.setString(2, this.salescontract.getText());
			stmt.setString(3, this.supplier.getText());
			stmt.setString(4, this.destination.getText());
			
			stmt.execute();
			conn.close();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	private void clearFields(ActionEvent event) {
		this.clientname.setText("");
		this.salescontract.setText("");
		this.supplier.setText("");
		this.destination.setText("");
	}
	
	
	@FXML
	private void deleteRow(ActionEvent event) {
		
		clientData client = clientTable.getSelectionModel().getSelectedItem();
		if (client != null) {
		    
		    try {
		    	Connection conn = dbConnection.getConnection();
		    	PreparedStatement statement = conn.prepareStatement("DELETE FROM clients WHERE cname = ?");
				statement.setString(1, client.getClientname());
				statement.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		    
		    
		}
	}
	
	@FXML
	private void clientsearch(ActionEvent event) {
		FilteredList<clientData> filteredClient = new FilteredList<>(data, b -> true);
		
		searchclient.textProperty().addListener((observable, oldValue, newValue) -> {
			filteredClient.setPredicate(clientData -> {
				if (newValue.isEmpty() || newValue.isBlank()|| newValue == null) {
					return true;
				}
				
				String searchKeyword = newValue.toLowerCase();
				
				if (clientData.getClientname().toLowerCase().indexOf(searchKeyword) > -1) {
					return true;
				} else {
					return false;
				}
				
			});
			
		});
		
		SortedList<clientData> sortedClient = new SortedList<>(filteredClient);
		
		sortedClient.comparatorProperty().bind(clientTable.comparatorProperty());
		
		clientTable.setItems(sortedClient);
	}
	
	
	//Invoice menu
	
	
	//calls in the text fields and columns for the invoice page
	@FXML
	private TextField clientname1;
	@FXML
	private TextField invoicenumber;
	@FXML
	private TextField item;
	@FXML
	private TextField quantity;
	@FXML
	private ComboBox<units> unit;
	@FXML
	private TextField price;
	@FXML
	private TextField containernumber;
	@FXML
	private TextField blnumber;
	@FXML
	private DatePicker date;
	@FXML
	private TextField searchinvoice;
	
	@FXML
	private TableView<invoiceData> invoiceTable;
	
	@FXML
	private TableColumn<invoiceData, String> clientcolumn;
	@FXML
	private TableColumn<invoiceData, String> invoicecolumn;
	@FXML
	private TableColumn<invoiceData, String> itemcolumn;
	@FXML
	private TableColumn<invoiceData, String> quantitycolumn;
	@FXML
	private TableColumn<invoiceData, String> unitcolumn;
	@FXML
	private TableColumn<invoiceData, String> pricecolumn;
	@FXML
	private TableColumn<invoiceData, String> containercolumn;
	@FXML
	private TableColumn<invoiceData, String> blcolumn;
	@FXML
	private TableColumn<invoiceData, String> datecolumn;
	
	
	private ObservableList<invoiceData> invoicedata;
	
	private String invoicesql = "SELECT * FROM invoices";
	
	
	@FXML
	private void loadinvoiceData(ActionEvent event) throws SQLException {
		
		try {
			
			Connection conn = dbConnection.getConnection();
			this.invoicedata = FXCollections.observableArrayList();
			
			ResultSet rs = conn.createStatement().executeQuery(invoicesql);
			while (rs.next()) {
				this.invoicedata.add(new invoiceData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)));
			}
			
			
		} catch (SQLException e) {
			System.err.println("Error" + e);
		}
		
		
		this.clientcolumn.setCellValueFactory(new PropertyValueFactory<invoiceData, String>("clientname1"));
		this.invoicecolumn.setCellValueFactory(new PropertyValueFactory<invoiceData, String>("invoicenumber"));
		this.itemcolumn.setCellValueFactory(new PropertyValueFactory<invoiceData, String>("item"));
		this.quantitycolumn.setCellValueFactory(new PropertyValueFactory<invoiceData, String>("quantity"));
		this.unitcolumn.setCellValueFactory(new PropertyValueFactory<invoiceData, String>("unit"));
		this.pricecolumn.setCellValueFactory(new PropertyValueFactory<invoiceData, String>("price"));
		this.containercolumn.setCellValueFactory(new PropertyValueFactory<invoiceData, String>("containernumber"));
		this.blcolumn.setCellValueFactory(new PropertyValueFactory<invoiceData, String>("blnumber"));
		this.datecolumn.setCellValueFactory(new PropertyValueFactory<invoiceData, String>("date"));
		
		this.invoiceTable.setItems(null);
		this.invoiceTable.setItems(this.invoicedata);
		
	}
	
	@FXML
	private void addinvoice(ActionEvent event) {
		String sqlInsert = "insert into invoices(cname, invoicenum, item, quantity, unit, price, containernum, blnum, date) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		try {
			
			Connection conn = dbConnection.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sqlInsert);
			
			stmt.setString(1, this.clientname1.getText());
			stmt.setString(2, this.invoicenumber.getText());
			stmt.setString(3, this.item.getText());
			stmt.setString(4, this.quantity.getText());
			stmt.setString(5, this.unit.getValue().toString());
			stmt.setString(6, this.price.getText());
			stmt.setString(7, this.containernumber.getText());
			stmt.setString(8, this.blnumber.getText());
			stmt.setString(9, this.date.getEditor().getText());
			
			stmt.execute();
			conn.close();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	private void clearinvoiceFields(ActionEvent event) {
		this.clientname1.setText("");
		this.invoicenumber.setText("");
		this.item.setText("");
		this.quantity.setText("");
		this.unit.setPromptText("Unit");
		this.price.setText("");
		this.containernumber.setText("");
		this.blnumber.setText("");
		this.date.setPromptText("");
		
	}
	
	
	@FXML
	private void deleteinvoiceRow(ActionEvent event) {
		
		invoiceData invoice = invoiceTable.getSelectionModel().getSelectedItem();
		if (invoice != null) {
		    
		    try {
		    	Connection conn = dbConnection.getConnection();
		    	PreparedStatement statement = conn.prepareStatement("DELETE FROM invoices WHERE cname = ?");
				statement.setString(1, invoice.getClientname1());
				statement.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		    
		    
		}
	}
	
	@FXML
	private void invoicesearch(ActionEvent event) {
		FilteredList<invoiceData> filteredInvoice = new FilteredList<>(invoicedata, b -> true);
		
		searchinvoice.textProperty().addListener((observable, oldValue, newValue) -> {
			filteredInvoice.setPredicate(invoiceData -> {
				if (newValue.isEmpty() || newValue.isBlank()|| newValue == null) {
					return true;
				}
				
				String searchKeyword = newValue.toLowerCase();
				
				if (invoiceData.getClientname1().toLowerCase().indexOf(searchKeyword) > -1) {
					return true;
				} else {
					return false;
				}
				
			});
			
		});
		
		SortedList<invoiceData> sortedInvoice = new SortedList<>(filteredInvoice);
		
		sortedInvoice.comparatorProperty().bind(invoiceTable.comparatorProperty());
		
		invoiceTable.setItems(sortedInvoice);
	}

	
	
}

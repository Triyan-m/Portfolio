package admin;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class invoiceData {
	
	private final StringProperty clientname1;
	private final StringProperty invoicenumber;
	private final StringProperty item;
	private final StringProperty quantity;
	private final StringProperty unit;
	private final StringProperty price;
	private final StringProperty containernumber;
	private final StringProperty blnumber;
	private final StringProperty date;
	
	public invoiceData(String clientName1, String invoiceNumber, String Item, String Quantity, String Unit, String Price, String containerNumber, String blNumber, String Date) {
		
		this.clientname1 = new SimpleStringProperty(clientName1);
		this.invoicenumber = new SimpleStringProperty(invoiceNumber);
		this.item = new SimpleStringProperty(Item);
		this.quantity = new SimpleStringProperty(Quantity);
		this.unit = new SimpleStringProperty(Unit);
		this.price = new SimpleStringProperty(Price);
		this.containernumber = new SimpleStringProperty(containerNumber);
		this.blnumber = new SimpleStringProperty(blNumber);
		this.date = new SimpleStringProperty(Date);
		
	}

	//Setters
	public void setClientname1(String clientname1) {
		this.clientname1.set(clientname1);
	}
	
	public void setInvoicenumber(String invoicenumber) {
		this.invoicenumber.set(invoicenumber);
	}
	
	public void setItem(String item) {
		this.item.set(item);
	}
	
	public void setQuantity(String quantity) {
		this.quantity.set(quantity);
	}
	
	public void setUnit(String unit) {
		this.unit.set(unit);
	}
	
	public void setPrice(String price) {
		this.price.set(price);
	}
	
	public void setContainernumber(String containernumber) {
		this.containernumber.set(containernumber);
	}
	
	public void setBlnumber(String blnumber) {
		this.blnumber.set(blnumber);
	}
	
	public void setDate(String date) {
		this.date.set(date);
	}
	
	//Getters
	public String getClientname1() {
		return clientname1.get();
	}

	public String getInvoicenumber() {
		return invoicenumber.get();
	}

	public String getItem() {
		return item.get();
	}
	
	public String getQuantity() {
		return quantity.get();
	}

	public String getUnit() {
		return unit.get();
	}

	public String getPrice() {
		return price.get();
	}

	public String getContainernumber() {
		return containernumber.get();
	}

	public String getBlnumber() {
		return blnumber.get();
	}

	public String getDate() {
		return date.get();
	}

	
	//String properties
	public StringProperty Clientname1Property() {
		return clientname1;
	}

	public StringProperty InvoicenumberProperty() {
		return invoicenumber;
	}

	public StringProperty ItemProperty() {
		return item;
	}
	
	public StringProperty QuantityProperty() {
		return quantity;
	}

	public StringProperty UnitProperty() {
		return unit;
	}

	public StringProperty PriceProperty() {
		return price;
	}

	public StringProperty ContainernumberProperty() {
		return containernumber;
	}

	public StringProperty BlnumberProperty() {
		return blnumber;
	}

	public StringProperty DateProperty() {
		return date;
	}
	
	
	
}
